#ifndef _MULTINOMIAL_H_
#define _MULTINOMIAL_H_

#include <Rcpp.h>
  Rcpp::IntegerVector rmultinom(int size,  Rcpp::NumericVector prob);
  
#endif
